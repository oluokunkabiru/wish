<script src="{{ asset("themes/$theme->name</script>/js/bootsrap/jquery.js") }}"></script>
<script src="{{ asset("themes/$them->name</script>/js/bootsrap/popper.js") }}"></script>
<script src="{{ asset("themes/$them->name/js/bootsrap/bootstrap.min.js") }}"></script>
<script src="{{ asset("themes/$them->name/js/bootsrap/jquery.countdown.min.js") }}"></script>

