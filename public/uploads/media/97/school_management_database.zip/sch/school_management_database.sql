-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2020 at 02:56 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(6) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `Phone_Number` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `profilePicture` text DEFAULT NULL,
  `AdminId` varchar(50) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `Phone_Number`, `gender`, `dob`, `password`, `profilePicture`, `AdminId`, `reg_date`) VALUES
(1, 'Oluokun kabir adesina', 'oka@vb.com', '', '', '', 'village', 'Admin Profile Pictures/Oluokun kabir adesina (2020-06-12-11-06-11).jpg', 'oka', '2020-06-12 21:33:11'),
(2, 'Adesina kabir Oluokun', 'oakadesina@admin.oic.org', '12345454', '', '2020-06-03', 'village', 'Admin Profile Pictures/Adesina kabir Oluokun (2020-06-17-12-06-37).jpg', 'c81e728d9d4c2f636f067f89cc14862c', '2020-06-17 10:44:37');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(6) NOT NULL,
  `CourseCode` varchar(255) NOT NULL,
  `CourseUnit` varchar(255) NOT NULL,
  `CourseTitle` varchar(255) NOT NULL,
  `CourseDesc` varchar(255) NOT NULL,
  `CourseLevel` varchar(100) NOT NULL,
  `CourseCategory` varchar(100) NOT NULL,
  `logo` text NOT NULL,
  `CourseId` varchar(50) NOT NULL,
  `courseReg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `CourseCode`, `CourseUnit`, `CourseTitle`, `CourseDesc`, `CourseLevel`, `CourseCategory`, `logo`, `CourseId`, `courseReg_date`) VALUES
(18, 'PYT101', '3', 'Python Programming', 'Thiss Is Python', '100', '8f14e45fceea167a5a36dedd4bea2543', '', '6f4922f45568161a8cdf4ad2299f6d23', '2020-10-26 13:19:03'),
(17, 'DAT102', '3', 'Database Structure', 'Databse Structuee', '100', '8f14e45fceea167a5a36dedd4bea2543', '', '70efdf2ec9b086079795c442636b55fb', '2020-10-26 13:18:22'),
(15, 'CSE102', '4', 'Introduction To Programming', 'This Is For Programming', '100', '8f14e45fceea167a5a36dedd4bea2543', '', '9bf31c7ff062936a96d3c8bd1f8f2ff3', '2020-10-26 10:06:56'),
(14, 'DAT301', '3', 'Database Design', 'For Introduction For Databse', '300', 'c4ca4238a0b923820dcc509a6f75849b', '', 'c4ca4238a0b923820dcc509a6f75849b', '2020-10-26 09:52:20'),
(16, 'CSE123', '3', 'Computer Sciencess', 'This Is  This', '200', '8f14e45fceea167a5a36dedd4bea2543', '', 'c74d97b01eae257e44aa9d5bade97baf', '2020-10-26 10:09:03');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(6) NOT NULL,
  `name` varchar(255) NOT NULL,
  `hod` varchar(255) NOT NULL,
  `FacultyCategory` varchar(255) NOT NULL,
  `logo` varchar(50) NOT NULL,
  `DepartmentId` varchar(50) NOT NULL,
  `DepartmentReg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`, `hod`, `FacultyCategory`, `logo`, `DepartmentId`, `DepartmentReg_date`) VALUES
(7, 'computer science', 'adesina', 'c4ca4238a0b923820dcc509a6f75849b', '', '8f14e45fceea167a5a36dedd4bea2543', '2020-10-26 09:50:40'),
(6, 'computer science and engineering', 'village boy', 'a87ff679a2f3e71d9181a67b7542122c', '', 'c4ca4238a0b923820dcc509a6f75849b', '2020-10-26 09:49:35'),
(8, 'computer science and technology', 'kabir', 'a87ff679a2f3e71d9181a67b7542122c', '', 'c9f0f895fb98ab9159f51fd0297e236d', '2020-10-26 10:11:10');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(6) NOT NULL,
  `name` varchar(255) NOT NULL,
  `dean` varchar(255) NOT NULL,
  `logo` text NOT NULL,
  `facultyId` varchar(50) NOT NULL,
  `FacultyReg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `name`, `dean`, `logo`, `facultyId`, `FacultyReg_date`) VALUES
(4, 'Computing', 'adesina', '', 'a87ff679a2f3e71d9181a67b7542122c', '2020-10-26 09:48:50'),
(3, 'Engineering', 'kabir', '', 'c4ca4238a0b923820dcc509a6f75849b', '2020-10-26 09:48:27');

-- --------------------------------------------------------

--
-- Table structure for table `registeredcourse`
--

CREATE TABLE `registeredcourse` (
  `id` int(6) NOT NULL,
  `student` varchar(255) NOT NULL,
  `studentId` varchar(50) NOT NULL,
  `matricNo` varchar(50) NOT NULL,
  `courseTitle` text NOT NULL,
  `courseUnit` varchar(255) NOT NULL,
  `courseCode` varchar(255) NOT NULL,
  `courseId` text NOT NULL,
  `level` varchar(10) NOT NULL,
  `semester` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `courseRegId` varchar(40) NOT NULL,
  `scores` varchar(100) NOT NULL,
  `grades` varchar(100) NOT NULL,
  `cgpa` varchar(4) NOT NULL,
  `points` varchar(100) NOT NULL,
  `totalunitpoint` varchar(100) NOT NULL,
  `class` varchar(20) NOT NULL,
  `status` varchar(30) NOT NULL,
  `CourseReg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registeredcourse`
--

INSERT INTO `registeredcourse` (`id`, `student`, `studentId`, `matricNo`, `courseTitle`, `courseUnit`, `courseCode`, `courseId`, `level`, `semester`, `department`, `courseRegId`, `scores`, `grades`, `cgpa`, `points`, `totalunitpoint`, `class`, `status`, `CourseReg_date`) VALUES
(1, '', 'c81e728d9d4c2f636f067f89cc14862c', '', 'Python Programming,Database Structure,Introduction To Programming', '3,3,4', 'PYT101,DAT102,CSE102', '6f4922f45568161a8cdf4ad2299f6d23,70efdf2ec9b086079795c442636b55fb,9bf31c7ff062936a96d3c8bd1f8f2ff3', '100', 'Rain Semester', '8f14e45fceea167a5a36dedd4bea2543', 'c4ca4238a0b923820dcc509a6f75849b', '61,44,38', 'B,E,F', '1.5', '4,1,0', '12,3,0', 'THIRD CLASS', '1,1,1', '2020-10-26 13:27:29'),
(2, '', 'c81e728d9d4c2f636f067f89cc14862c', '', 'Python Programming,Database Structure,Introduction To Programming', '3,3,4', 'PYT101,DAT102,CSE102', '6f4922f45568161a8cdf4ad2299f6d23,70efdf2ec9b086079795c442636b55fb,9bf31c7ff062936a96d3c8bd1f8f2ff3', '100', 'Harmattan Semester', '8f14e45fceea167a5a36dedd4bea2543', 'c81e728d9d4c2f636f067f89cc14862c', '80,24,0', 'A,F,F', '1.5', '5,0,0', '15,0,0', 'THIRD CLASS', '1,1,1', '2020-10-26 13:30:12');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(6) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `Phone_Number` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `CourseTaken` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `profilePicture` text NOT NULL,
  `StaffId` varchar(50) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `name`, `email`, `Phone_Number`, `password`, `CourseTaken`, `category`, `faculty`, `state`, `city`, `address`, `gender`, `dob`, `profilePicture`, `StaffId`, `reg_date`) VALUES
(1, 'Oluokun,adesina,village', 'voaoluokun@staff.oic.org', '83765836', '813f8ce580f276558ce9e5093468b1ab', '9bf31c7ff062936a96d3c8bd1f8f2ff3', '8f14e45fceea167a5a36dedd4bea2543', 'c4ca4238a0b923820dcc509a6f75849b', '', '', '', '', '2020-09-27', '', 'c4ca4238a0b923820dcc509a6f75849b', '2020-10-26 11:06:45');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(6) NOT NULL,
  `SurName` varchar(30) NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `Phone_Number` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `Level` varchar(50) NOT NULL,
  `matricNo` varchar(10) NOT NULL,
  `CurrentSemester` varchar(30) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Faculty` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `profilePicture` text NOT NULL,
  `NextOfKin` varchar(100) NOT NULL,
  `CGPA` varchar(5) NOT NULL,
  `class` varchar(50) NOT NULL,
  `StudentId` varchar(50) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `SurName`, `FirstName`, `LastName`, `email`, `Phone_Number`, `password`, `Level`, `matricNo`, `CurrentSemester`, `Department`, `Faculty`, `state`, `city`, `Address`, `dob`, `gender`, `profilePicture`, `NextOfKin`, `CGPA`, `class`, `StudentId`, `reg_date`) VALUES
(1, 'oluokun', 'kabir', 'Adesinas', 'okakabir@student.oic.org', '958847893', '813f8ce580f276558ce9e5093468b1ab', '100', '200000', 'Rain Semester', 'c4ca4238a0b923820dcc509a6f75849b', 'a87ff679a2f3e71d9181a67b7542122c', 'oyo', 'iseyin', 'isalu', '', 'Male', '../student/Student Profile Pictures/OLUOKUN KABIR ADESINAS (2020-10-26-10-10-27).jpg', 'oluokun najeem', '', '', 'c4ca4238a0b923820dcc509a6f75849b', '2020-10-26 11:36:53'),
(2, 'adesina', 'kabiru', 'oluokun', 'akokabiru@student.oic.org', '28758923', '813f8ce580f276558ce9e5093468b1ab', '200', '200001', 'Rain Semester', '8f14e45fceea167a5a36dedd4bea2543', 'c4ca4238a0b923820dcc509a6f75849b', '', '', '', '', '', 'Student Profile Pictures/ADESINA KABIRU OLUOKUN (2020-10-26-02-10-50).jpg', '', '1.5', 'THIRD CLASS', 'c81e728d9d4c2f636f067f89cc14862c', '2020-10-26 13:30:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`CourseId`),
  ADD UNIQUE KEY `id` (`id`) USING BTREE,
  ADD KEY `CourseCategory` (`CourseCategory`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`DepartmentId`),
  ADD UNIQUE KEY `id` (`id`) USING BTREE,
  ADD KEY `FacultyCategory` (`FacultyCategory`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`facultyId`),
  ADD UNIQUE KEY `id` (`id`) USING BTREE;

--
-- Indexes for table `registeredcourse`
--
ALTER TABLE `registeredcourse`
  ADD PRIMARY KEY (`courseRegId`),
  ADD UNIQUE KEY `id` (`id`) USING BTREE,
  ADD KEY `studentId` (`studentId`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`StaffId`),
  ADD UNIQUE KEY `id` (`id`) USING BTREE,
  ADD KEY `faculty` (`faculty`),
  ADD KEY `CourseTaken` (`CourseTaken`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`StudentId`),
  ADD UNIQUE KEY `id` (`id`) USING BTREE,
  ADD KEY `Department` (`Department`),
  ADD KEY `Faculty` (`Faculty`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `registeredcourse`
--
ALTER TABLE `registeredcourse`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`CourseCategory`) REFERENCES `department` (`DepartmentId`);

--
-- Constraints for table `department`
--
ALTER TABLE `department`
  ADD CONSTRAINT `department_ibfk_1` FOREIGN KEY (`FacultyCategory`) REFERENCES `faculty` (`facultyId`);

--
-- Constraints for table `registeredcourse`
--
ALTER TABLE `registeredcourse`
  ADD CONSTRAINT `registeredcourse_ibfk_1` FOREIGN KEY (`studentId`) REFERENCES `student` (`StudentId`),
  ADD CONSTRAINT `registeredcourse_ibfk_2` FOREIGN KEY (`department`) REFERENCES `department` (`DepartmentId`);

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`faculty`) REFERENCES `faculty` (`facultyId`),
  ADD CONSTRAINT `staff_ibfk_2` FOREIGN KEY (`CourseTaken`) REFERENCES `courses` (`CourseId`),
  ADD CONSTRAINT `staff_ibfk_3` FOREIGN KEY (`category`) REFERENCES `department` (`DepartmentId`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`Department`) REFERENCES `department` (`DepartmentId`),
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`Faculty`) REFERENCES `faculty` (`facultyId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
